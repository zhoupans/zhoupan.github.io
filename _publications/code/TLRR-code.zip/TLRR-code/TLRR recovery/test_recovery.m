addpath(genpath('proximal_operator'));
addpath(genpath('tSVD'));


p = 0.2;%%add 20% noise into each image
indimgs=[1:10];

noise_imshow={};
orgianl_imshow={};
TRPCA_imshow={};
TLRR_imshow={};
psnrs_TRPCA=zeros(length(indimgs),1);
psnrs_TLRR=zeros(length(indimgs),1);
RMSE_TRPCA=zeros(length(indimgs),1);
RMSE_TLRR=zeros(length(indimgs),1);
for i = 1 : length(indimgs)
    %% read image
    id = indimgs(i);
    pic_name = [ 'data/I (' num2str(id) ').jpg'];
    I = double(imread(pic_name));
    X = I/255.0;
    
    %% add noise
    [n1,n2,n3] = size(X);
    maxP = max(X(:));
    Omega = find(rand(n1*n2*n3,1)<p);
    XX=X;
    XX(Omega)=randi([0,255],length(Omega),1)./255.0;
    noise_imshow{i}=XX;
    orgianl_imshow{i}=X;
    
    %% recovery
    %% test R-TPCA
    [n1,n2,n3]=size(X);
    opts.lambda = 1/sqrt(max(n1,n2)*n3);
    opts.mu = 1e-4;
    opts.tol = 1e-8;
    opts.rho = 1.2;
    opts.max_iter = 800;
    opts.DEBUG = 0;
    
    [ L,E,rank] = dictionary_learning( XX, opts);

    %% PSNR
    L_RTPCA = max(L,0);
    L_RTPCA = min(L_RTPCA,maxP);
    [psnrs_TRPCA(i),RMSE_TRPCA(i)]= PSNR(X,L_RTPCA,maxP);
    TRPCA_imshow{i}=L_RTPCA;
    
    %% TLRR
    tic;
    %% approximate L, since sometimes R-TPCA cannot produce a good dictionary
    tho=50;
    Debug = 0;
    [ L_hat,trank,U,V,S ] = prox_low_rank(L,tho);
    if Debug
        fprintf('\n\n ||L_hat-L||=%.3e,  rank=%d\n\n',tnorm(L_hat-L,'fro'),trank);
    end
    LL=tprod(U,S);
    %% test R-TLRR
    max_iter=800;

    [Z,tlrr_E,Z_rank,err_va ] = Tensor_LRR(XX,LL,max_iter,Debug);
    
    L_TLRR=tprod(LL,Z);
    Time_TLRR(i)=toc;
    
    %% compute PSNR
    L_TLRR = max(L_TLRR,0);
    L_TLRR = min(L_TLRR,maxP);
    [psnrs_TLRR(i),RMSE_TLRR(i)] = PSNR(X,L_TLRR,maxP);
    TLRR_imshow{i}=L_TLRR;
    
   
    fprintf('\n %d-th image, RTPCA  RSE=%.4e, psnr=%.4f',i,RMSE_TRPCA(i),psnrs_TRPCA(i));
    fprintf('\n              RTLRR  RSE=%.4e, psnr=%.4f\n',RMSE_TLRR(i),psnrs_TLRR(i));
end

