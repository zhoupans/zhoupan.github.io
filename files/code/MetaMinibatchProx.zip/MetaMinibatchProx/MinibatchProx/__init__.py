"""
MinibatchProx
"""
