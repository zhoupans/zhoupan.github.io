"""
Module configuration.
"""

from setuptools import setup

setup(
    name='Meta-MinibatchProx',
    version='0.0.1',
    description='Meta-MinibatchProx meta-learning approach',
    long_description='Meta-MinibatchProx meta-learning for classification tasks',
    url='https://panzhous.github.io/',
    author='Pan Zhou',
    author_email='pzhou@u.nus.edu',
    license='NUS',
    keywords='meta learning',
    packages=['Meta-MinibatchProx'],
    install_requires=[
        'numpy>=1.0.0,<2.0.0',
        'Pillow>=4.0.0,<5.0.0'
    ],
    extras_require={
        "tf": ["tensorflow>=1.0.0"],
        "tf_gpu": ["tensorflow-gpu>=1.0.0"],
    }
)
